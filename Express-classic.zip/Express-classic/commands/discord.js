exports.run = (client, message, args, ops) => {
  message.reply("**Express Support**\nIf you need help with the bot, give suggestions, or report some bugs, here is the right place.\nhttps://discord.gg/HKqb6V7");
}