# Express Classic

Express Classic is a version of the bot that can be deployed without any problems.

## Deploying

Heroku offers you the possibility to host your own instance of the Discord bot, you only need a brain and some requirements for the bot to work.

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/ItzLightyHD/Express/tree/classic)
